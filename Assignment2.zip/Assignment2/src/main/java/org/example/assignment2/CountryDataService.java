package org.example.assignment2;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CountryDataService {
    private static final String API_URL = "https://restcountries.com/v3.1/";

    public static CountryData callAPI(String countryName) throws IOException, InterruptedException {
        //if we received "Star Wars", we need to translate that to be "Star%20Wars"
        countryName = countryName.replaceAll(" ", "%20");

        String uri = API_URL + "name/" + countryName;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(uri)).build();

        HttpResponse<String> httpResponse = client.send(httpRequest, HttpResponse.BodyHandlers
                .ofString());

        Gson gson = new Gson();
        return gson.fromJson(httpResponse.body(), CountryData.class);
    }
    public static List<CountryData> fetchCountryData() throws Exception {
        try {
            CountryData response = callAPI("braz");
            List<CountryData> countryDataList = new ArrayList<>();
            countryDataList.add(response);
            return countryDataList;
        } catch(Exception ex)
        {
            throw new Exception(ex.getMessage());
        }

        /*
        JsonArray jsonArray = gson.fromJson(responseBody, JsonArray.class);

        List<CountryData> countryDataList = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            JsonObject countryObj = jsonArray.get(i).getAsJsonObject();
            String name = countryObj.get("name").getAsJsonObject().get("common").getAsString();
            String capital = countryObj.get("capital").getAsJsonArray().get(0).getAsString();
            long population = countryObj.get("population").getAsLong();

            JsonArray languagesArray = countryObj.getAsJsonArray("languages");
            List<String> languages = new ArrayList<>();
            for (int j = 0; j < languagesArray.size(); j++) {
                languages.add(languagesArray.get(j).getAsJsonObject().get("name").getAsString());
            }

            CountryData countryData = new CountryData(countryName, capital, population, languages);
            countryDataList.add(countryData);
        }

         */

        //return countryDataList;
    }
}