package org.example.assignment2;

import com.google.gson.annotations.SerializedName;

public class CountryData {
    @SerializedName("name")
    private CountryName name;

    public CountryName getName() {
        return name;
    }

    public void setName(CountryName name) {
        this.name = name;
    }
}