package org.example.assignment2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;

import java.io.IOException;
import java.util.List;

public class HelloController {
    @FXML
    private ListView<String> countryListView;

    public ObservableList<String> countryNames = FXCollections.observableArrayList();

    public void initialize() {
        try {
            List<CountryData> countryDataList = CountryDataService.fetchCountryData();
            for (CountryData countryData : countryDataList) {
                countryNames.add(countryData.getName().getCommon());
            }
            countryListView.setItems(countryNames);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}