package org.example.assignment2;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ApiResponse {
    private ArrayList<CountryData> countries;

    public ArrayList<CountryData> getCountries() {
        return countries;
    }
}
