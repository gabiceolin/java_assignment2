module org.example.assignment2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires com.google.gson;
    requires java.net.http;


    opens org.example.assignment2 to javafx.fxml;
    exports org.example.assignment2;
}