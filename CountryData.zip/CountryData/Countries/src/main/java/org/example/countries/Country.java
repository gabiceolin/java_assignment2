package org.example.countries;

import com.google.gson.annotations.SerializedName;

class Country implements Comparable<Country> {
    @SerializedName("name")
    private String name;

    @SerializedName("capital")
    private String capital;

    @SerializedName("population")
    private long population;

    @SerializedName("flag")
    private String flagUrl;

    public Country(String name, String capital, long population, String flagUrl) {
        this.name = name;
        this.capital = capital;
        this.population = population;
        this.flagUrl = flagUrl;
    }

    public String getName() {
        return name ;
    }

    public String getCapital() {
        return capital;
    }

    public long getPopulation() {
        return population;
    }

    public String getFlagUrl() {
        return flagUrl;
    }

    public String toString()
    {
        return String.format("%s",name);
    }

    @Override
    public int compareTo(Country o) {
        return this.getName().compareTo(o.getName());
    }
}