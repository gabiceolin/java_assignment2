package org.example.countries;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.example.countries.Main;

public class CountryViewController {
    @FXML
    private TextField searchTextField; // TextField to enter the country name

    @FXML
    private ListView<Country> countryListView; // ListView to display the list of countries

    @FXML
    private ImageView flagImageView;

    @FXML
    private void initialize() {
        // This listener updates the flagImageView when a country is selected
        countryListView.getSelectionModel()
                .selectedItemProperty()
                .addListener((obs, oldValue, countrySelected) ->{
                    if (countrySelected != null) {
                        try {
                            flagImageView.setImage(new Image(countrySelected.getFlagUrl()));
                        } catch (IllegalArgumentException e) {
                            e.printStackTrace();
                        }
                    }
                });

        // Set a custom cell factory to handle mouse clicks on the list items
        countryListView.setCellFactory(param -> new ListCell<Country>() {
            @Override
            protected void updateItem(Country country, boolean empty) {
                super.updateItem(country, empty);
                if (empty || country == null) {
                    setText(null);
                } else {
                    setText(country.getName());
                }
            }
        });

        // Add event handler for mouse double-clicks on list items
        countryListView.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) { // Check for double-click
                Country selectedCountry = countryListView.getSelectionModel().getSelectedItem();
                if (selectedCountry != null) {
                    try {
                        openDetailsView(selectedCountry);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    private void openDetailsView(Country country) throws IOException {
        // Load the details.fxml file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("details.fxml"));
        Parent root = loader.load();

        // Get the controller for the details view and set the country details
        DetailsController detailsController = loader.getController();
        detailsController.setCountryDetails(country);

        // Create a new stage and set the scene
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Country Detail");
        stage.getIcons().add(new Image(Main.class.getResourceAsStream("images/icon.jpeg")));
        Main.close();
        stage.show();
    }

    @FXML
    private void searchCountry() throws IOException, InterruptedException {
        String countryName = searchTextField.getText().trim(); // Get the country name from the TextField
        String uri = "https://restcountries.com/v3.1/name/" + countryName;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(uri)).build(); // Create a new HttpRequest

        HttpResponse<String> httpResponse = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());

        Gson gson = new Gson();
        JsonArray jsonArray = gson.fromJson(httpResponse.body(), JsonArray.class);

        ObservableList<Country> countries = FXCollections.observableArrayList(); // Create an ObservableList to store the countries
        countryListView.getItems().clear();

        if (jsonArray.isJsonArray()) {
            for (int i = 0; i < jsonArray.size(); i++) {
                JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();

                String name = jsonObject.get("name").getAsJsonObject().get("common").getAsString();
                String capital = jsonObject.get("capital").getAsJsonArray().get(0).getAsString();
                long population = jsonObject.get("population").getAsLong();
                String flagUrl = jsonObject.get("flags").getAsJsonObject().get("png").getAsString();

                Country country = new Country(name, capital, population, flagUrl);
                countries.add(country);
            }
        } else {
            JsonObject jsonObject = jsonArray.getAsJsonObject();

            String name = jsonObject.get("name").getAsJsonObject().get("common").getAsString();
            String capital = jsonObject.get("capital").getAsJsonArray().get(0).getAsString();
            long population = jsonObject.get("population").getAsLong();
            String flagUrl = jsonObject.get("flags").getAsJsonObject().get("png").getAsString();

            Country country = new Country(name, capital, population, flagUrl);
            countries.add(country);
        }

        if (!countries.isEmpty()) {
            countryListView.getItems().addAll(countries);
            countryListView.getSelectionModel().selectFirst();
            loadCountryDetails(countries.get(0));
        } else {
            clearCountryDetails();
        }
    }

    private void loadCountryDetails(Country country) {
       flagImageView.setImage(new javafx.scene.image.Image(country.getFlagUrl()));
    }

    private void clearCountryDetails() {
        flagImageView.setImage(null);
    }
}