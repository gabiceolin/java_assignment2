package org.example.countries;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

public class CountryViewController {
    @FXML
    private TextField searchTextField;

    @FXML
    private ListView<Country> countryListView;

    @FXML
    private Label nameLabel;

    @FXML
    private Label capitalLabel;

    @FXML
    private Label populationLabel;

    @FXML
    private ImageView flagImageView;

    @FXML
    private void initialize()
    {
        countryListView.getSelectionModel()
                .selectedItemProperty()
                .addListener((obs, oldValue, countrySelected) ->{
                    if (countrySelected != null)
                    {
                        try {
                            flagImageView.setImage(new Image(countrySelected.getFlagUrl()));
                        } catch (IllegalArgumentException e)
                        {
                            //posterImageView.setImage(new Image(Main.class.getResourceAsStream("images/default_poster.png")));
                        }
                    }
                    else
                    {
                        //selectedVBox.setVisible(false);
                    }
                });
    }

    @FXML
    private void searchCountry() throws IOException, InterruptedException {
        String countryName = searchTextField.getText().trim();
        String uri = "https://restcountries.com/v3.1/name/" + countryName;

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest httpRequest = HttpRequest.newBuilder().uri(URI.create(uri)).build();

        HttpResponse<String> httpResponse = client.send(httpRequest, HttpResponse.BodyHandlers.ofString());

        Gson gson = new Gson();
        JsonArray jsonArray = gson.fromJson(httpResponse.body(), JsonArray.class);

        ObservableList<Country> countries = FXCollections.observableArrayList();
        if (jsonArray.isJsonArray()) {
            for (int i = 0; i < jsonArray.size(); i++) {
                JsonObject jsonObject = jsonArray.get(i).getAsJsonObject();

                String name = jsonObject.get("name").getAsJsonObject().get("common").getAsString();
                String capital = jsonObject.get("capital").getAsJsonArray().get(0).getAsString();
                long population = jsonObject.get("population").getAsLong();
                String flagUrl = jsonObject.get("flags").getAsJsonObject().get("png").getAsString();

                Country country = new Country(name, capital, population, flagUrl);
                countries.add(country);
            }
        } else {
            JsonObject jsonObject = jsonArray.getAsJsonObject();

            String name = jsonObject.get("name").getAsJsonObject().get("common").getAsString();
            String capital = jsonObject.get("capital").getAsJsonArray().get(0).getAsString();
            long population = jsonObject.get("population").getAsLong();
            String flagUrl = jsonObject.get("flags").getAsJsonObject().get("png").getAsString();

            Country country = new Country(name, capital, population, flagUrl);
            countries.add(country);
        }

        if (!countries.isEmpty()) {
            countryListView.getItems().addAll(countries);
            countryListView.getSelectionModel().selectFirst();
            loadCountryDetails(countries.get(0));
        } else {
            clearCountryDetails();
        }
    }

    private void loadCountryDetails(Country country) {
        nameLabel.setText(country.getName() );
        capitalLabel.setText(country.getCapital());
        populationLabel.setText(String.valueOf(country.getPopulation()));
        flagImageView.setImage(new javafx.scene.image.Image(country.getFlagUrl()));
    }

    private void clearCountryDetails() {
        nameLabel.setText("");
        capitalLabel.setText("");
        populationLabel.setText("");
        flagImageView.setImage(null);
    }
}