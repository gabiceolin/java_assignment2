package org.example.countries;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class DetailsController {

    @FXML
    private Label nameLabel; // Label to display the country name

    @FXML
    private Label capitalLabel;

    @FXML
    private Label populationLabel;

    @FXML
    private ImageView flagImageView;

    public void setCountryDetails(Country country) {
        nameLabel.setText(country.getName() );
        capitalLabel.setText(country.getCapital());
        populationLabel.setText(String.valueOf(country.getPopulation()));
        flagImageView.setImage(new javafx.scene.image.Image(country.getFlagUrl()));
    }

    private void clearCountryDetails() {
        nameLabel.setText("");
        capitalLabel.setText("");
        populationLabel.setText("");
        flagImageView.setImage(null);
    }
    @FXML
    private void backToSearch(ActionEvent event) throws IOException {
        // Load the details.fxml file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        Parent root = loader.load();


        // Create a new stage and set the scene
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.setTitle("Countries Data");
        stage.getIcons().add(new Image(Main.class.getResourceAsStream("images/icon.jpeg")));
        Main.close();
        stage.show();
        /*
        // Close the current stage (details view)
        Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        currentStage.close();

        // Show the hello view stage
        stage.show();*/
    }

}